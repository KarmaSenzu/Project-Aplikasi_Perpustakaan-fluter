package com.example.mobile_programming

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
